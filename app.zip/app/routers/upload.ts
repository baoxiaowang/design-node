export default [
  [
    'POST',
    '/api/upload',
    'upload.uploadFiles',
  ],
];
